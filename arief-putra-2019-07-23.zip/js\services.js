angular.module('ngApp.services', [])

