
var locale = 'en';
var url = 'http://localhost/public';

var ngApp = angular.module('ngApp', ['ionic', 'ngResource', 'ngApp.controllers', 'ngApp.services'])

.run(function($ionicPlatform, $rootScope, $ionicLoading) {
    $rootScope.$on('loading:show', function() {
        $ionicLoading.show({
            noBackdrop: false
        });
    });

    $rootScope.$on('loading:hide', function() {
        $ionicLoading.hide();
    });

	$ionicPlatform.ready(function() {
		/* Ready */
	});
})

.config(function($stateProvider, $locationProvider, $urlRouterProvider, $ionicConfigProvider, $httpProvider) {

 $locationProvider.hashPrefix('!'); /*.html5Mode(true)*/ $ionicConfigProvider.backButton.previousTitleText(false).text(''); $httpProvider.interceptors.push(function($rootScope) { return { /* http request show loading */ request: function(config) { $rootScope.$broadcast('loading:show'); return config }, /* Hide loading in case any occurred */ requestError: function(response) { $rootScope.$broadcast('loading:hide'); return response }, /* Hide loading once got response */ response: function(response) { $rootScope.$broadcast('loading:hide'); return response }, /* Hide loading if got any response error */ responseError: function(response) { $rootScope.$broadcast('loading:hide'); return response } } });	$ionicConfigProvider.tabs.position("bottom"); $stateProvider .state('nav', { url: '/nav', abstract: true, templateUrl: 'nav.html', controller: 'NavCtrl' }) .state('nav.widget1', { url: '/widget/:widget/:func/:sl/:id', views: { 'mainContent': { templateUrl: function(params) { return url + '/api/v1/widget/route/' + params.widget + '/' + params.func + '/' + params.sl + '/' + params.id; } } } }) .state('nav.widget2', { url: '/widget/:widget/:func/:sl/:id/:extra', views: { 'mainContent': { templateUrl: function(params) { return url + '/api/v1/widget/route/' + params.widget + '/' + params.func + '/' + params.sl + '/' + params.id + '/' + params.extra; } } } }) .state('nav.home', { url: '/home', class: 'cHome', cache: false, views: { 'mainContent': { templateUrl: 'templates//api/v1/mobile/view/CB39-24KA-253E-7F9E?_escaped_fragment_=home.html', controller: 'cHomeCtrl' } } }) .state('nav.instagram', { url: '/instagram', class: 'cInstagram', cache: false, views: { 'mainContent': { templateUrl: 'templates//api/v1/mobile/view/CB39-24KA-253E-7F9E?_escaped_fragment_=instagram.html', controller: 'cInstagramCtrl' } } }) .state('nav.facebook', { url: '/facebook', class: 'cFacebook', cache: false, views: { 'mainContent': { templateUrl: 'templates//api/v1/mobile/view/CB39-24KA-253E-7F9E?_escaped_fragment_=facebook.html', controller: 'cFacebookCtrl' } } }) .state('nav.about-us', { url: '/about-us', class: 'cAboutUs', cache: false, views: { 'mainContent': { templateUrl: 'templates//api/v1/mobile/view/CB39-24KA-253E-7F9E?_escaped_fragment_=about-us.html', controller: 'cAboutUsCtrl' } } }) .state('nav.contact-us', { url: '/contact-us', class: 'cContactUs', cache: false, views: { 'mainContent': { templateUrl: 'templates//api/v1/mobile/view/CB39-24KA-253E-7F9E?_escaped_fragment_=contact-us.html', controller: 'cContactUsCtrl' } } }) .state('nav.youtube', { url: '/youtube', class: 'cYoutube', cache: false, views: { 'mainContent': { templateUrl: 'templates//api/v1/mobile/view/CB39-24KA-253E-7F9E?_escaped_fragment_=youtube.html', controller: 'cYoutubeCtrl' } } }); $urlRouterProvider.otherwise('/nav/home');

});

